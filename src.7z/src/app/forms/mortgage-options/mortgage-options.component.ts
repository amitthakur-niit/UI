import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mortgage-options',
  templateUrl: './mortgage-options.component.html',
  styleUrls: ['./mortgage-options.component.scss']
})
export class MortgageOptionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
